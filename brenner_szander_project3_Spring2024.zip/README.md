Name: Szander Brenner
Section: 23374
UFL email: szander.brenner@ufl.edu
System: Windows
Compiler: g++ mingw64 C++11
SFML version: 2.5.1
IDE: Clion
Other notes: None